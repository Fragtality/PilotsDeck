﻿// Implement settingsModel for the Action
var settingsModel = {
	EnableSwitching: false,
	ProfilesInstalled: false,
	UseAlphaDefault: true,
	ProfileX_Name: "",
	ProfileY_Name: "",
	ProfileZ_Name: ""
};

// Fill Select Boxes for Actions here
function fillSelectBoxes() {

}

// Show/Hide elements on Form (required function)
function updateForm() {

}
