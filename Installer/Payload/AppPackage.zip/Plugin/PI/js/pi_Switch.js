﻿var imageSelectBoxes = ["DefaultImage", "ImageGuard"];
var toggleOnControlsMap = [];
var toggleOffControlsMap = [];
var toggleOnDivMap = [];
var toggleOffDivMap = []

function updateForm() {

}
